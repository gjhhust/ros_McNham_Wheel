#ifndef MBOT_LINUX_SERIAL_H
#define MBOT_LINUX_SERIAL_H

#include "robot_start.h" 







extern void serialInit();
extern void writeSpeed(double V_x, double V_y,double V_z,unsigned char ctrlFlag);
extern bool readSpeed(double &V_x_Actual,double &V_y_Actual,double &V_w_Actual,double &Angle);
unsigned char getCrc8(unsigned char *ptr, unsigned short len);

void odom_pub_calcu(void);
double sin_cal(double theta);
#endif
