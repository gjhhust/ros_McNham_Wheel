#include "sdk_V3_use.h"

#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#include "std_srvs/Empty.h"

#include <stdio.h>
#include <thread>
#include <mutex>
#include <condition_variable>

#ifndef _countof
#define _countof(_Array) (int)(sizeof(_Array) / sizeof(_Array[0]))
#endif

#define DEG2RAD(x) ((x)*M_PI/180.)

extern std::string  g_strLidarID;
extern std::string strPort;              // For Linux OS
extern int iBaud;
extern std::string strLidarModel;


LstNodeDistQ2 lstG;
LstNodeDistQ2 lstG_temp;
std::mutex mu;						//互斥锁
std::condition_variable cond;       //条件变量

void push_Scan(LstNodeDistQ2 lstG,
                ros::Publisher *pub,
                std::string frame_id,
                ros::Time now,
                double scan_time,
                float angle_min, float angle_max,
                size_t node_count,
                float max_distance
                ){
	// tsNodeInfo msg= lstG.front();
	// lstG.pop_front();
	sensor_msgs::LaserScan scan_msg;

    scan_msg.header.frame_id = frame_id;
    scan_msg.header.stamp = now;

	scan_msg.angle_min =  angle_min;
    scan_msg.angle_max =  angle_max;

    scan_msg.angle_increment = DEG2RAD(0.9);


    scan_msg.scan_time = scan_time;
    scan_msg.time_increment = scan_time / (double)(node_count-1);
    scan_msg.range_min = 0.1;
    scan_msg.range_max = max_distance;//8.0;

    scan_msg.intensities.resize(node_count);
    scan_msg.ranges.resize(node_count);
    int i=0;
    for(auto sInfo : lstG)
    {
        float read_value = sInfo.distance_q2/4.0f/1000;
          
        //if(i>=node_count) break;
        //ROS_INFO("Main: Angle=%0.2f,Dist=%d\n" ,(double)sInfo.angle_q6_checkbit/64.0f  , sInfo.distance_q2/4 );

        if (read_value == 0.0)
            scan_msg.ranges[i] = std::numeric_limits<float>::infinity();
        else
            scan_msg.ranges[i] = read_value;
        scan_msg.intensities[i] = (float) (sInfo.syn_quality >> 2);

        i++;
    }
	
    pub->publish(scan_msg);
}
int rtn = 0;
bool bPollMode = true;
bool bDistQ2 = true;
bool bLoop = false;

bool ralidar_Init(void)
{

	std::string strVer = getSDKVersion();
    std::cout << "Main: SDK verion=" << strVer.c_str()<< std::endl;

    auto funErrorCode = std::bind(sdkCallBackFunErrorCode, std::placeholders::_1);
	setSDKCallBackFunErrorCode(funErrorCode);

    auto funSecondInfo = std::bind(sdkCallBackFunSecondInfo, std::placeholders::_1);
    setSDKCallBackFunSecondInfo(funSecondInfo);

    if(!bPollMode)//call back
    {
        auto funPointCloud = std::bind(sdkCallBackFunPointCloud, std::placeholders::_1);
        setSDKCallBackFunPointCloud(funPointCloud);

        auto funDistQ2 = std::bind(sdkCallBackFunDistQ2, std::placeholders::_1);
        setSDKCallBackFunDistQ2(funDistQ2);
    }

	int iReadTimeoutms = 2;//10

	setSDKCircleDataMode();
	rtn = hcSDKInitialize(strPort.c_str(), strLidarModel.c_str(), iBaud, iReadTimeoutms, bDistQ2, bLoop, bPollMode);

    if (rtn != 1)
    {
		hcSDKUnInit();
		ROS_INFO("Main: Init sdk failed!\n");
		getchar();
		exit(0);
		return false;
        
    }

	setSDKLidarPowerOn(true);
	setSDKCircleDataMode();

	std::this_thread::sleep_for(std::chrono::milliseconds(3000));
	g_strLidarID = getSDKLidarID();
	
	
	ROS_INFO( "Lidar ID=%s\n" , getSDKLidarID());
	ROS_INFO( "Factory Info:%s\n" , getSDKFactoryInfo());
	ROS_INFO( "Main: Firmware ver:%s\n", getSDKFirmwareVersion() );
	ROS_INFO( "Main: Hardware ver:%s\n", getSDKHardwareVersion());
	ROS_INFO( "Main: Lidar model:%s\n" , getSDKLidarModel() );

    return true;
}
short Data_Full_Flag=0;
void ralidar_RUN(void){
	std::unique_lock<std::mutex> locker(mu);
	if(bPollMode)
        {
            if(bDistQ2)
            {
                if (getSDKScanData(lstG, false))
				{
					if (lstG.size() > 0)
					{
						Data_Full_Flag=1;
					}
					
				}
            }
        }

}

int main(int argc, char * argv[]) {
    ros::init(argc, argv, "HC_rplidar_node");

    std::string serial_port = "/dev/lidar";
    int serial_baudrate = 115200;
    std::string frame_id = "laser_frame";
    bool inverted = false;
    bool angle_compensate = true;
    float max_distance = 8.0;
    int angle_compensate_multiple = 1;//it stand of angle compensate at per 1 degree
    ros::NodeHandle nh;
    ros::Publisher scan_pub = nh.advertise<sensor_msgs::LaserScan>("scan", 1000);

    ROS_INFO("HCralidar running on ROS package rplidar_ros. ");

    if(ralidar_Init()){
        ROS_INFO("Init successfully");
    }
    //打开串口

    

    ros::Time start_scan_time;
    ros::Time end_scan_time;
    double scan_duration;
    size_t   count=0;


	tsNodeInfo Now_Node;
    tsNodeInfo Last_Node;
	//std::thread receiverThread(ralidar_RUN);
    while (ros::ok()) {
        ralidar_RUN();
        //std::unique_lock<std::mutex> locker(mu);
		//cond.wait(locker);
		//LstNodeDistQ2 lstG = lstG;
        if(Data_Full_Flag == 1){
            Last_Node = Now_Node;
            Now_Node = lstG.back();
            //ROS_INFO("\nangle_Now:[%.4f]\n",(Now_Node.angle_q6_checkbit)/64.0f);

            if( ((Last_Node.angle_q6_checkbit)/64.0f) - ((Now_Node.angle_q6_checkbit)/64.0f) >300.0 ){
                //说明一圈的数据中有分叉点
                //ROS_INFO("\nThis is a new Datas\n");

                // //输出列表后八位以便调试
                // LstNodeDistQ2::reverse_iterator  p1;        //定义迭代器 用于遍历
                // int i=0; 
                // for(p1=lstG.rbegin();p1!=lstG.rend();p1++)
                // {
				// 	ROS_INFO("Angle=%0.2f  " ,(double)p1->angle_q6_checkbit/64.0f);
                //     i++;
                //     if(i==8) break;//输出八个就行
                // }
                // ROS_INFO("\n");


                //取出多余的元素
                LstNodeDistQ2::reverse_iterator  p;//定义迭代器 用于遍历
                LstNodeDistQ2::reverse_iterator  p_last=lstG.rbegin();
                int k=0; 
                for(p=lstG.rbegin();p!=lstG.rend();p++)
                {
                    //再次判断
					if( (p->angle_q6_checkbit)/64.0f - (p_last->angle_q6_checkbit)/64.0f > 300.0 ){
                        //ROS_INFO("!!!!!Angle fen cha dian is=%0.4f  \n" ,(double)p->angle_q6_checkbit/64.0f);//输出分叉点

                        //将分叉点后面的多余元素放到temp中
                        for(int j=0;j<k;j++){
                            lstG_temp.push_back(lstG.back());//把最后一个转移
                            ROS_INFO("Nowing temp list node is=%0.4f  " ,(double)(lstG_temp.back()).angle_q6_checkbit/64.0f);
                            lstG.pop_back();//删除
                        }
                        //ROS_INFO("\n");
                        break;
                    }
                    k++;
                    p_last = p;

                    if(k==9)//还是只需要处理8个数据     
                    {
                        //ROS_INFO("@@@@@@ERROR is not find fenchadian\n");   
                        break;
                    }
                }

                
                //push_Scan
                end_scan_time = ros::Time::now();
                scan_duration = (end_scan_time - start_scan_time).toSec();
                count = lstG.size();
                float angle_min = DEG2RAD(((lstG.front()).angle_q6_checkbit)/64.0f);
                float angle_max = DEG2RAD(((lstG.back()).angle_q6_checkbit)/64.0f);
                ROS_INFO("SIZE:[%d] , scan_time:[%.4f], angle_min:[%.4f], angle_max:[%.4f]\n",count,scan_duration,angle_min,angle_max);
                push_Scan(lstG,
                        &scan_pub,
                        frame_id,
                        end_scan_time,
                        scan_duration,
                        angle_min, angle_max,
                        count,
                        max_distance
                        );
            
                //clear
                lstG.clear();
                huigui_node();

                //ROS_INFO("angle_first:[%.4f]\n",((lstG.front()).angle_q6_checkbit)/64.0f);//调试
                start_scan_time = ros::Time::now();
            }
            

            Data_Full_Flag = 0; 
        }



        ros::spinOnce();
    }

    // done!
	hcSDKUnInit();
    // drv->stop();
    // drv->stopMotor();
    // RPlidarDriver::DisposeDriver(drv);
    return 0;
}


//将temp内的node移动回原列表
void huigui_node(void){

    while(lstG_temp.empty() != true){
        lstG.push_back(lstG_temp.back());//把最后一个转移
        //ROS_INFO("Nowing Huigui list node is=%0.4f  " ,(double)(lstG.back()).angle_q6_checkbit/64.0f);
        lstG_temp.pop_back();//删除
    }
    //ROS_INFO("\n");
}